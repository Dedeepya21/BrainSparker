package com.reversesearch.brainsparker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity {

    private EditText Name,MailID,Password,ConfirmPassword,MobileNumber;
    private Button Register,Login;
    private String SName,SMailID,SPassword,SMobileNumber,SConfirmPassword;

    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Name=findViewById(R.id.Register_Name);
        MailID=findViewById(R.id.Register_MailID);
        Password=findViewById(R.id.Register_Password);
        ConfirmPassword=findViewById(R.id.Register_ConfirmPassword);
        MobileNumber=findViewById(R.id.MobileNumber);
        Login=findViewById(R.id.Register_LoginButton);
        Register=findViewById(R.id.Register_RegisterButton);


        progressBar=findViewById(R.id.Register_ProgressBar);

        progressBar.setVisibility(View.INVISIBLE);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Register.this,Login.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
            }
        });

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Register_User_to_DB();
            }
        });

    }

    public boolean ValidateEmail(String mail){
        return (mail.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$"));
    }

    private void Register_User_to_DB(){

        SName=Name.getText().toString().trim();
        SMailID=MailID.getText().toString().trim();
        SPassword=Password.getText().toString().trim();
        SConfirmPassword=ConfirmPassword.getText().toString().trim();
        SMobileNumber=MobileNumber.getText().toString().trim();

        if(SName.equals("")||SMailID.equals("")||SMobileNumber.equals("")||SPassword.equals("")||SConfirmPassword.equals("")||SConfirmPassword.equals(SPassword)==false||ValidateEmail(SMailID)==false||SMobileNumber.length()<10||SPassword.length()<8||SPassword.length()<8){
            if(SName.equals("")){
                Name.setError("Required");
            }

            if(SMailID.equals("")){
                MailID.setError("Required");
            }else if(ValidateEmail(SMailID)==false){
                MailID.setError("Invalid MailID");
            }

            if(SMobileNumber.equals("")){
                MobileNumber.setError("Required");
            }else if(SMobileNumber.length()<10){
                MobileNumber.setError("Mobile Number Must be 10 Digits");
            }
            if(SPassword.equals("")){
                Password.setError("Required");
            }else if(SPassword.length()<8){
                Password.setError("Must be atleast 8 Characters");
            }
            if(SConfirmPassword.equals("")){
                ConfirmPassword.setError("Required");
            }else if(SConfirmPassword.length()<8){
                ConfirmPassword.setError("Must be atleast 8 Characters");
            }
            if(SPassword.length()>=8 && SConfirmPassword.length()>=8 && SConfirmPassword.equals(SPassword)==false){
                ConfirmPassword.setError("Passwords must Match");
            }

        }else {
            ViewEnableDisable(false);
            progressBar.setVisibility(View.VISIBLE);
            //Toast.makeText(this, "Hi", Toast.LENGTH_SHORT).show();
            String url = BuildConfig.Base_URL+"ReverseSearchQuiz/Register.php";
            final SharedPreferences sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);
            StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    Toast.makeText(Register.this, "" + response, Toast.LENGTH_SHORT).show();

                    if(response.equals("Registration Successfull")){
                        startActivity(new Intent(Register.this,Login.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                    }

                    ViewEnableDisable(true);
                    progressBar.setVisibility(View.INVISIBLE);

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
//                Toast.makeText(QuizActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                }
            }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("Name", SName);
                    params.put("MailID", SMailID);
                    params.put("MobileNumber", SMobileNumber);
                    params.put("Password", SPassword);
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);

        }
    }

    private void ViewEnableDisable(boolean Status){

        Name.setEnabled(Status);
        MailID.setEnabled(Status);
        MobileNumber.setEnabled(Status);
        Password.setEnabled(Status);
        ConfirmPassword.setEnabled(Status);
        Login.setEnabled(Status);
        Register.setEnabled(Status);

    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(Register.this,Login.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
    }
}