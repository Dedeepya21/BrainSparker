package com.reversesearch.brainsparker;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {

    private EditText MailID,Password;
    private Button Register,Login,ForgotPasswordButton;
    private String SMailID,SPassword;
    private JSONObject jsonObject;
    private TextView ErrorTextView;
    private ScrollView Login_ScrollView;

    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        MailID=findViewById(R.id.Login_MailID);
        Password=findViewById(R.id.Login_Password);
        Login=findViewById(R.id.Login_LoginButton);
        Register=findViewById(R.id.Login_RegisterButton);
        ForgotPasswordButton=findViewById(R.id.Login_ForgotPasswordButton);
        ErrorTextView=findViewById(R.id.Login_ErrorStatus);

        progressBar=findViewById(R.id.Login_ProgressBar);

        progressBar.setVisibility(View.INVISIBLE);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ErrorTextView.setVisibility(View.INVISIBLE);
                checkUserCredentials();
            }
        });

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this,Register.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
            }
        });

        ForgotPasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    ForgotPassword();
                }catch (Exception e){
                    Toast.makeText(Login.this, ""+e, Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

    public boolean ValidateEmail(String mail){
        return (mail.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$"));
    }

    private void checkUserCredentials(){

        SMailID=MailID.getText().toString().trim();
        SPassword=Password.getText().toString().trim();

        if(SMailID.equals("")||SPassword.equals("")){
            if(SMailID.equals("")){
                MailID.setError("Required");
            }
            if(SPassword.equals("")){
                Password.setError("Required");
            }
            ErrorTextView.setText("Both fields Required");
            ErrorTextView.setVisibility(View.VISIBLE);
        }else if(ValidateEmail(SMailID)==false){
            MailID.setError("Invalid MailID");
            ErrorTextView.setText("Invalid Mail ID");
            ErrorTextView.setVisibility(View.VISIBLE);
        }else if(SPassword.length()<8){
            Password.setError("Must be atleast 8 Characters");
            ErrorTextView.setText("Password must be atleast 8 Characters");
            ErrorTextView.setVisibility(View.VISIBLE);
        }else {

            ViewEnableDisable(false);
            progressBar.setVisibility(View.VISIBLE);
            String url = BuildConfig.Base_URL+"ReverseSearchQuiz/Login.php";
            final SharedPreferences sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);
            StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    try {
                        //Toast.makeText(Login.this, "" + response, Toast.LENGTH_SHORT).show();
                        jsonObject=new JSONObject(response);
                        if (jsonObject.getString("Status").equals("Login Successfull")) {
                            sharedPreferences.edit().putString("Name", jsonObject.getString("Name")).apply();
                            sharedPreferences.edit().putString("MailID", jsonObject.getString("MailID")).apply();
                            sharedPreferences.edit().putString("MobileNumber", jsonObject.getString("MobileNumber")).apply();
                            Toast.makeText(Login.this, "Login Successfull", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(Login.this, Home.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                        }else{
                            if(jsonObject.getString("Status").trim().equals("User Not Exists")){
                                MailID.setError("User Not Exists");
                            }else if(jsonObject.getString("Status").trim().equals("Wrong Password")){
                                Password.setError("Wrong Password");
                            }
                            ErrorTextView.setText(jsonObject.getString("Status").trim());
                            ErrorTextView.setVisibility(View.VISIBLE);

                            progressBar.setVisibility(View.INVISIBLE);
                            ViewEnableDisable(true);
                            //Toast.makeText(Login.this, ""+jsonObject.getString("Status"), Toast.LENGTH_SHORT).show();
                        }
                    }catch (Exception e){
                        //Toast.makeText(Login.this, ""+e, Toast.LENGTH_SHORT).show();
                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
//                Toast.makeText(QuizActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                }
            }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("MailID", SMailID);
                    params.put("Password", SPassword);
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);

        }
    }


    private void ForgotPassword(){

        AlertDialog.Builder builder=new AlertDialog.Builder(Login.this);
        View ForgotPasswordView=getLayoutInflater().inflate(R.layout.forgot_password_dialog_box,null);
        final TextView Email=ForgotPasswordView.findViewById(R.id.ForgotPassword_MailID);
        final LinearLayout EmailParent=ForgotPasswordView.findViewById(R.id.ForgotPassword_MailID_Parent);
        final TextView ErrorTextView=ForgotPasswordView.findViewById(R.id.ForgotPassword_ErrorTextView);
        final Button SendMailorOkButton=ForgotPasswordView.findViewById(R.id.ForgotPassword_SendMailButton);
        final ProgressBar ForgotprogressBar=ForgotPasswordView.findViewById(R.id.ForgotPassword_ProgressBar);
        ForgotprogressBar.setVisibility(View.INVISIBLE);
        ImageView Close=ForgotPasswordView.findViewById(R.id.ForgotPassword_CloseButton);
        final LinearLayout ForgotPassword_MailSentStatusLinearLayout=ForgotPasswordView.findViewById(R.id.ForgotPassword_MailSentStatusLinearLayout);
        builder.setView(ForgotPasswordView);
        final AlertDialog alertDialog=builder.create();
        alertDialog.setCancelable(false);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.show();

        SendMailorOkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ErrorTextView.setVisibility(View.INVISIBLE);

                if(SendMailorOkButton.getText().toString().trim().equals("Send Password")){
                    if(Email.getText().toString().trim().equals("")){
                        ErrorTextView.setText("Mail Cannot be Empty");
                        ErrorTextView.setVisibility(View.VISIBLE);
                    }else if(ValidateEmail(Email.getText().toString().trim())==false){
                        ErrorTextView.setText("Invalid Mail ID");
                        ErrorTextView.setVisibility(View.VISIBLE);
                    }else{
                        SendMailorOkButton.setEnabled(false);
                        Email.setEnabled(false);
                        ForgotprogressBar.setVisibility(View.VISIBLE);
                        String url = BuildConfig.Base_URL+"ReverseSearchQuiz/ForgotPasswordSendMailtoUser.php";
                        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                if (response.trim().equals("Mail Sent!")) {
                                    ForgotprogressBar.setVisibility(View.INVISIBLE);
                                    EmailParent.setVisibility(View.INVISIBLE);
                                    SendMailorOkButton.setEnabled(true);
                                    SendMailorOkButton.setText("Ok");
                                    ForgotPassword_MailSentStatusLinearLayout.setVisibility(View.VISIBLE);
                                } else {
                                    ForgotprogressBar.setVisibility(View.INVISIBLE);
                                    SendMailorOkButton.setEnabled(true);
                                    Email.setEnabled(true);
                                    ErrorTextView.setText("Error occurred please try again");
                                    ErrorTextView.setVisibility(View.VISIBLE);
                                }


                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                ErrorTextView.setText("Error occurred please try again");
                                ErrorTextView.setVisibility(View.VISIBLE);
//                Toast.makeText(QuizActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                            }
                        }) {
                            @Override
                            protected Map<String, String> getParams() {
                                Map<String, String> params = new HashMap<>();
                                params.put("MailID", Email.getText().toString().trim());
                                return params;
                            }
                        };
                        RequestQueue requestQueue = Volley.newRequestQueue(Login.this);
                        requestQueue.add(stringRequest);
                    }


                }else {
                    alertDialog.dismiss();
                }
            }
        });

        Close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

    }

    private void ViewEnableDisable(boolean Status){

        MailID.setEnabled(Status);
        Password.setEnabled(Status);
        Login.setEnabled(Status);
        Register.setEnabled(Status);
        ForgotPasswordButton.setEnabled(Status);

    }


}