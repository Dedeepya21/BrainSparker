package com.reversesearch.brainsparker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class MyCourses extends AppCompatActivity {

    private ProgressBar progressBar;
    private LinearLayout Courses_LinearLayout;
    private SharedPreferences sharedPreferences;
    private JSONArray jsonArray;
    private JSONObject jsonObject;
    private int TotalCourses,ResourceId;
    private TextView NoCourses;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_courses);

        progressBar=findViewById(R.id.MyCourses_ProgressBar);
        Courses_LinearLayout=findViewById(R.id.MyCourses_Linear_Layout);
        NoCourses=findViewById(R.id.MyCourses_NoCoursesTextView);

        sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);

        GetMyCoursesStatus();

    }


    private void GetMyCoursesStatus(){

        String url = BuildConfig.Base_URL+"ReverseSearchQuiz/GetUserCoursesStatus.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                //Toast.makeText(MyCourses.this, "" + response, Toast.LENGTH_SHORT).show();


                try{
                    jsonArray=new JSONArray(response);
                    progressBar.setVisibility(View.INVISIBLE);

                    TotalCourses=jsonArray.length();

                    if(TotalCourses==0){
                        NoCourses.setVisibility(View.VISIBLE);
                    }else {
                        for (int i = 0; i < TotalCourses; i++) {
                            jsonObject = jsonArray.getJSONObject(i);

                            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
                            View Course = getLayoutInflater().inflate(R.layout.mycourses_courses_buttons, null);

                            TextView CourseNumber = Course.findViewById(R.id.MyCourses_Button_LanguageNumber);
                            TextView LanguageName = Course.findViewById(R.id.MyCourses_Button_LanguageName);
                            TextView Status = Course.findViewById(R.id.MyCourses_Button_LanguageStatus);
                            ImageView CourseImage = Course.findViewById(R.id.MyCourses_Button_LanguageImage);

                            ResourceId = getResources().getIdentifier("@drawable/" + (jsonObject.getString("language").toLowerCase().replaceAll(Pattern.quote("+"), "p").replaceAll(" ", "")), null, getPackageName());
                            CourseImage.setImageDrawable(getResources().getDrawable(ResourceId));

                            CourseNumber.setText((i + 1) + " / " + TotalCourses);
                            LanguageName.setText(jsonObject.getString("language"));
                            if (jsonObject.getString("Status").trim().equals("Completed")) {
                                Status.setTextColor(Color.parseColor("#3CD36E"));
                                Status.setText("Completed");
                            } else {
                                Status.setTextColor(Color.parseColor("#A22C08"));
                                Status.setText("In Progress");
                            }


                            if (i == 0) {
                                layoutParams.setMargins(0, 0, 0, 0);
                            } else {
                                layoutParams.setMargins(0, 10, 0, 0);
                            }

                            Course.setLayoutParams(layoutParams);
                            Courses_LinearLayout.addView(Course);


                        }
                    }
                }catch (Exception e){
                    //Toast.makeText(MyCourses.this, ""+e, Toast.LENGTH_SHORT).show();
                }



            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
//                Toast.makeText(QuizActivity.this, error.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("MailID", sharedPreferences.getString("MailID",""));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);


    }


}