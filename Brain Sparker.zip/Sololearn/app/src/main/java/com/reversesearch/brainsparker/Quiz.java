package com.reversesearch.brainsparker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class Quiz extends AppCompatActivity{

    private TextView Language,Topic,Question,Questions_Count_Display_Status_TextView;
    private Button OptionA,OptionB,OptionC,OptionD,UserSelectedOptionButton,CorrectOptionButton;
    private Button Previous,NextTopic,NextorRetry;
    private SharedPreferences sharedPreferences;
    private int QuestionNumber=-1,TotalQuestions;
    private JSONArray jsonArray;
    private JSONObject jsonObject;
    private String UserAnswer,CorrectAnswer,Description;
    private ScrollView QuestionViewScrollView;
    private ProgressBar progressBar;
    private MediaPlayer CorrectAnswerSound,WrongAnswerSound,CongratulationsSound;
    private int ResourceId,NextorRetryDisplayTime;
    private ImageView LanguageImageView;
    private Runnable mRunnable;
    private Handler mHandler;
    private String LanguageCompletionStatus;
    private boolean DescriptionOpened[];
    private Button ShowDescription;
    private int QuestionPoints[],EachQuestionPoint=5,TotalScore=0,No_of_Questions_Selected_Description=0;
    private boolean Answered[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        Language=findViewById(R.id.Quiz_LanguageName);
        Topic=findViewById(R.id.Quiz_TopicName);
        Question=findViewById(R.id.Quiz_TopicQuestion);
        OptionA=findViewById(R.id.Quiz_TopicOptionA);
        OptionB=findViewById(R.id.Quiz_TopicOptionB);
        OptionC=findViewById(R.id.Quiz_TopicOptionC);
        OptionD=findViewById(R.id.Quiz_TopicOptionD);
        Previous=findViewById(R.id.Quiz_TopicPreviousButton);
        NextTopic=findViewById(R.id.Quiz_TopicNextTopic);
        NextorRetry=findViewById(R.id.Quiz_TopicNextorRetryButton);
        QuestionViewScrollView=findViewById(R.id.Quiz_TopicQuestionViewScrollView);
        progressBar=findViewById(R.id.Quiz_ProgressBar);
        LanguageImageView=findViewById(R.id.Quiz_LanguageImage);
        Questions_Count_Display_Status_TextView=findViewById(R.id.Quiz_Question_Count_TextView);
        ShowDescription=findViewById(R.id.Quiz_ShowDescription);

        CorrectAnswerSound=MediaPlayer.create(this, R.raw.correct_ans);
        WrongAnswerSound=MediaPlayer.create(this, R.raw.wrong_answer);
        CongratulationsSound=MediaPlayer.create(this, R.raw.congrats);

        sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);
        mHandler=new Handler();

        ResourceId = getResources().getIdentifier("@drawable/"+(sharedPreferences.getString("language","").toLowerCase().replaceAll(Pattern.quote("+"),"p").replaceAll(" ","")), null, getPackageName());
        LanguageImageView.setImageDrawable(getResources().getDrawable(ResourceId));

        Language.setText(sharedPreferences.getString("language",""));
        Topic.setText(sharedPreferences.getString("topic",""));
        GetQuestionsfromDB();


        NextorRetry.setVisibility(View.INVISIBLE);
        Previous.setVisibility(View.INVISIBLE);
        ShowDescription.setVisibility(View.INVISIBLE);
        QuestionViewScrollView.setVisibility(View.INVISIBLE);



        if(sharedPreferences.getBoolean("LastTopic",false)){
            LanguageCompletionStatus="Completed";
        }else{
            LanguageCompletionStatus="In Progress";
        }


        ShowDescription.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DescriptionOpened[QuestionNumber]=true;
                OpenDescriptionDialog();
            }
        });



        NextorRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(NextorRetry.getText().toString().trim().equals("Next Topic")||NextorRetry.getText().toString().trim().equals("Go to Home")){
                    Navigate_to_NextTopic();
                }else {
                    if (NextorRetry.getText().toString().trim().equals("Retry")) {
                        QuestionNumber--;
                    }
                    SetQuestionView();
                }
            }
        });

        Previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                QuestionNumber=QuestionNumber-2;
                SetQuestionView();
            }
        });



        //ShowTopicCompletionPopUp();
    }

    private void GetQuestionsfromDB(){
        String url = BuildConfig.Base_URL+"ReverseSearchQuiz/GetQuestionsfromDB.php";
        final SharedPreferences sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    progressBar.setVisibility(View.INVISIBLE);
                    QuestionViewScrollView.setVisibility(View.VISIBLE);
                    //ShowDescription.setVisibility(View.VISIBLE);
                    jsonArray=new JSONArray(response);
                    TotalQuestions=jsonArray.length();
                    DescriptionOpened=new boolean[TotalQuestions];
                    QuestionPoints=new int[TotalQuestions];
                    Answered=new boolean[TotalQuestions];
                    for(int b=0;b<TotalQuestions;b++){
                        DescriptionOpened[b]=false;
                        QuestionPoints[b]=EachQuestionPoint;
                        Answered[b]=false;
                    }
                    //Toast.makeText(Quiz.this, "" + response, Toast.LENGTH_SHORT).show();
                    SetQuestionView();
                }catch (Exception e){
                    //Toast.makeText(Quiz.this, ""+e, Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
//                Toast.makeText(QuizActivity.this, error.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("language",sharedPreferences.getString("language",""));
                params.put("topic",sharedPreferences.getString("topic",""));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void SetQuestionView(){
        QuestionNumber++;

        Questions_Count_Display_Status_TextView.setText((QuestionNumber+1)+" / "+(TotalQuestions));

        try{
            jsonObject=jsonArray.getJSONObject(QuestionNumber);
            Question.setText(jsonObject.getString("question"));
            OptionA.setText(jsonObject.getString("op1"));
            OptionB.setText(jsonObject.getString("op2"));
            OptionC.setText(jsonObject.getString("op3"));
            OptionD.setText(jsonObject.getString("op4"));
            CorrectAnswer=jsonObject.getString("answer");
            Description=jsonObject.getString("description");

            //if(QuestionPoints[QuestionNumber]<5) {
            //    if (Description.trim().equals("")) {
            //        ShowDescription.setVisibility(View.INVISIBLE);
            //    } else {
            //        ShowDescription.setVisibility(View.VISIBLE);
            //    }
            //}else{
            //    ShowDescription.setVisibility(View.INVISIBLE);
            //}


        }catch(Exception e){
            //Toast.makeText(this, ""+e, Toast.LENGTH_SHORT).show();
        }


        if(Answered[QuestionNumber]){
            ShowDescription.setVisibility(View.INVISIBLE);
            NextorRetry.setVisibility(View.VISIBLE);
            if(QuestionNumber==TotalQuestions-1){
                if(sharedPreferences.getBoolean("LastTopic",false)){
                    NextorRetry.setText("Go to Home");
                }else {
                    NextorRetry.setText("Next Topic");
                }
            }else{
                NextorRetry.setText("Next");
            }
            OptionA.setEnabled(false);
            OptionB.setEnabled(false);
            OptionC.setEnabled(false);
            OptionD.setEnabled(false);

            try {

                if (jsonObject.getString("op1").equals(CorrectAnswer)) {
                    OptionA.setBackgroundResource(R.drawable.quiz_correct_answer);
                }else {
                    OptionA.setBackgroundResource(R.drawable.quiz_options_shape);
                }

                if(jsonObject.getString("op2").equals(CorrectAnswer)) {
                    OptionB.setBackgroundResource(R.drawable.quiz_correct_answer);
                }else {
                    OptionB.setBackgroundResource(R.drawable.quiz_options_shape);
                }

                if(jsonObject.getString("op3").equals(CorrectAnswer)) {
                    OptionC.setBackgroundResource(R.drawable.quiz_correct_answer);
                }else {
                    OptionC.setBackgroundResource(R.drawable.quiz_options_shape);
                }

                if(jsonObject.getString("op4").equals(CorrectAnswer)) {
                    OptionD.setBackgroundResource(R.drawable.quiz_correct_answer);
                }else {
                    OptionD.setBackgroundResource(R.drawable.quiz_options_shape);
                }

            }catch (Exception e){
                //Toast.makeText(this, ""+e, Toast.LENGTH_SHORT).show();
            }

        }else {
            OptionA.setEnabled(true);
            OptionB.setEnabled(true);
            OptionC.setEnabled(true);
            OptionD.setEnabled(true);
            NextorRetry.setVisibility(View.INVISIBLE);

            if(QuestionPoints[QuestionNumber]<5) {
                if (Description.trim().equals("")) {
                    ShowDescription.setVisibility(View.INVISIBLE);
                } else {
                    ShowDescription.setVisibility(View.VISIBLE);
                }
            }else{
                ShowDescription.setVisibility(View.INVISIBLE);
            }

            OptionA.setBackgroundResource(R.drawable.quiz_options_shape);
            OptionB.setBackgroundResource(R.drawable.quiz_options_shape);
            OptionC.setBackgroundResource(R.drawable.quiz_options_shape);
            OptionD.setBackgroundResource(R.drawable.quiz_options_shape);

        }
        //OptionA.setBackgroundColor(Color.parseColor("#E1D5F8"));
        //OptionB.setBackgroundColor(Color.parseColor("#E1D5F8"));
        //OptionC.setBackgroundColor(Color.parseColor("#E1D5F8"));
        //OptionD.setBackgroundColor(Color.parseColor("#E1D5F8"));



        if(QuestionNumber==0){
            Previous.setVisibility(View.INVISIBLE);
        }else{
            Previous.setVisibility(View.VISIBLE);
        }

    }

    public void GetAnswer(View view){
        OptionA.setEnabled(false);
        OptionB.setEnabled(false);
        OptionC.setEnabled(false);
        OptionD.setEnabled(false);
        switch (view.getId()){
            case R.id.Quiz_TopicOptionA:
                UserSelectedOptionButton=findViewById(R.id.Quiz_TopicOptionA);
                break;
            case R.id.Quiz_TopicOptionB:
                UserSelectedOptionButton=findViewById(R.id.Quiz_TopicOptionB);
                break;
            case R.id.Quiz_TopicOptionC:
                UserSelectedOptionButton=findViewById(R.id.Quiz_TopicOptionC);
                break;
            case R.id.Quiz_TopicOptionD:
                UserSelectedOptionButton=findViewById(R.id.Quiz_TopicOptionD);
                break;
        }
        UserAnswer=UserSelectedOptionButton.getText().toString().trim();
        if(UserAnswer.equals(CorrectAnswer)){
            CorrectAnswerSound.start();
            Answered[QuestionNumber]=true;
            //UserSelectedOptionButton.setBackgroundColor(Color.parseColor("#3AA54F"));
            UserSelectedOptionButton.setBackgroundResource(R.drawable.quiz_correct_answer);
            NextorRetryDisplayTime=1;
            if(QuestionNumber==TotalQuestions-1){
                //NextTopic.setVisibility(View.VISIBLE);
                if(sharedPreferences.getBoolean("LastTopic",false)){
                    NextorRetry.setText("Go to Home");
                    if(sharedPreferences.getString("TopicCompletionStatus","").equals("Completed")) {

                    }else{
                        ShowLanguageCompletionPopUp();
                    }

                }else {
                    NextorRetry.setText("Next Topic");
                    if(sharedPreferences.getString("TopicCompletionStatus","").equals("Completed")) {

                    }else {
                        ShowTopicCompletionPopUp();
                    }
                }
            }else{
                NextorRetry.setText("Next");
            }
        }else{
            NextorRetryDisplayTime=1;
            WrongAnswerSound.start();
            //UserSelectedOptionButton.setBackgroundColor(Color.parseColor("#A54037"));
            UserSelectedOptionButton.setBackgroundResource(R.drawable.quiz_wrong_answer);
            NextorRetry.setText("Retry");
            if(QuestionPoints[QuestionNumber]>2){
                QuestionPoints[QuestionNumber]=QuestionPoints[QuestionNumber]-1;
            }
        }

        mRunnable=new Runnable() {

            @Override
            public void run() {
                NextorRetry.setVisibility(View.VISIBLE);
            }
        };
        mHandler.postDelayed(mRunnable,NextorRetryDisplayTime*1000);

    }


    private void Navigate_to_NextTopic(){

        for(int z=0;z<TotalQuestions;z++){
            if(DescriptionOpened[z]) {
                No_of_Questions_Selected_Description = No_of_Questions_Selected_Description + 1;
            }
            TotalScore=TotalScore+QuestionPoints[z];
        }
        TotalScore=TotalScore-2*No_of_Questions_Selected_Description;

        String url = BuildConfig.Base_URL+"ReverseSearchQuiz/UpdateTopicCompletionStatustoDB.php";
        //final SharedPreferences sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                //Toast.makeText(Register.this, "" + response, Toast.LENGTH_SHORT).show();
                if(response.equals("Updated Successfully")) {
                    if(LanguageCompletionStatus=="Completed") {
                        startActivity(new Intent(Quiz.this, Home.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                    }else{
                        startActivity(new Intent(Quiz.this, Topics.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK));
                    }
                }else{
                    Toast.makeText(Quiz.this, "Try Again", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Quiz.this, "Try Again", Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("MailID", sharedPreferences.getString("MailID",""));
                params.put("Name",sharedPreferences.getString("Name",""));
                params.put("language", sharedPreferences.getString("language",""));
                params.put("topic", sharedPreferences.getString("topic",""));
                params.put("LanguageCompletion",LanguageCompletionStatus);
                params.put("Score",TotalScore+"");
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void ShowTopicCompletionPopUp(){

        AlertDialog.Builder builder=new AlertDialog.Builder(Quiz.this);
        View CongratsView=getLayoutInflater().inflate(R.layout.congratulations_on_topic_completion,null);
        TextView Name=CongratsView.findViewById(R.id.Congratulations_topic_UserName);
        TextView Topic=CongratsView.findViewById(R.id.Congratulations_topic_TopicName);
        TextView Language=CongratsView.findViewById(R.id.Congratulations_topic_LanguageName);
        ImageView LanguageImage=CongratsView.findViewById(R.id.Congratulations_topic_ImageView);
        final Button OkButton=CongratsView.findViewById(R.id.Congratulations_topic_OkButton);
        OkButton.setVisibility(View.INVISIBLE);
        builder.setView(CongratsView);

        Name.setText(sharedPreferences.getString("Name",""));
        Topic.setText(sharedPreferences.getString("topic",""));
        LanguageImage.setImageDrawable(getResources().getDrawable(ResourceId));
        Language.setText(sharedPreferences.getString("language",""));

        final AlertDialog alertDialog=builder.create();
        alertDialog.setCancelable(false);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        CongratulationsSound.start();

        OkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });
        alertDialog.show();



        mRunnable=new Runnable() {

            @Override
            public void run() {
                OkButton.setVisibility(View.VISIBLE);
            }
        };
        mHandler.postDelayed(mRunnable,4*1000);

    }


    private void ShowLanguageCompletionPopUp(){

        AlertDialog.Builder builder=new AlertDialog.Builder(Quiz.this);
        View CongratsView=getLayoutInflater().inflate(R.layout.congratulations_on_language_completion,null);
        TextView Name=CongratsView.findViewById(R.id.Congratulations_Language_UserName);
        TextView Language=CongratsView.findViewById(R.id.Congratulations_Language_LanguageName);
        ImageView LanguageImage=CongratsView.findViewById(R.id.Congratulations_Language_ImageView);
        final Button OkButton=CongratsView.findViewById(R.id.Congratulations_Language_OkButton);
        OkButton.setVisibility(View.INVISIBLE);
        builder.setView(CongratsView);

        Name.setText(sharedPreferences.getString("Name",""));
        LanguageImage.setImageDrawable(getResources().getDrawable(ResourceId));
        Language.setText(sharedPreferences.getString("language",""));

        final AlertDialog alertDialog=builder.create();
        alertDialog.setCancelable(false);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        CongratulationsSound.start();

        OkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });
        alertDialog.show();



        mRunnable=new Runnable() {

            @Override
            public void run() {
                OkButton.setVisibility(View.VISIBLE);
            }
        };
        mHandler.postDelayed(mRunnable,4*1000);

    }


    private void OpenDescriptionDialog(){

        AlertDialog.Builder builder=new AlertDialog.Builder(Quiz.this);
        View DescriptionView=getLayoutInflater().inflate(R.layout.quiz_description_dialog,null);
        TextView Description_TextView=DescriptionView.findViewById(R.id.Quiz_Description_Dialog_TextView);
        final Button OkButton=DescriptionView.findViewById(R.id.Quiz_Description_Dialog_OkButton);
        builder.setView(DescriptionView);

        Description_TextView.setText(Description);

        final AlertDialog alertDialog=builder.create();
        alertDialog.setCancelable(false);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


        OkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });
        alertDialog.show();

    }



    @Override
    public void onBackPressed() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(Quiz.this);

        alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Quiz.super.onBackPressed();
            }
        });

        alertDialog.setNegativeButton("No", null);

        alertDialog.setMessage("Do you Really want to exit Quiz");
        alertDialog.setTitle("Brain Sparker");
        alertDialog.show();

    }


}